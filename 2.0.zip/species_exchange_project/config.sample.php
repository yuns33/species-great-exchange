<?php
// 安装向导会自动生成 config.php，请勿手动公开数据库密码。
return [
  'db_host' => 'localhost',
  'db_name' => 'species_exchange',
  'db_user' => 'root',
  'db_pass' => '',
  'db_charset' => 'utf8mb4'
];

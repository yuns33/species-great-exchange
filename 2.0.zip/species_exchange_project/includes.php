<?php
declare(strict_types=1);
if (session_status() !== PHP_SESSION_ACTIVE) session_start();
function config(): array { static $c=null; if($c===null){$f=__DIR__.'/config.php'; if(!is_file($f)){http_response_code(503); exit('请先访问 /install/ 完成安装');} $c=require $f;} return $c; }
function db(): PDO { static $pdo=null; if(!$pdo){$c=config();$dsn="mysql:host={$c['db_host']};dbname={$c['db_name']};charset=utf8mb4";$pdo=new PDO($dsn,$c['db_user'],$c['db_pass'],[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]);}return $pdo; }
function e($v): string{return htmlspecialchars((string)$v,ENT_QUOTES,'UTF-8');}
function json_out($data,int $status=200): never{http_response_code($status);header('Content-Type: application/json; charset=utf-8');echo json_encode($data,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);exit;}
function admin_required(): void{if(empty($_SESSION['admin_id'])){header('Location: login.php');exit;}}
function csrf(): string{if(empty($_SESSION['csrf']))$_SESSION['csrf']=bin2hex(random_bytes(24));return $_SESSION['csrf'];}
function csrf_check(): void{if(!hash_equals($_SESSION['csrf']??'',$_POST['csrf']??'')){http_response_code(419);exit('请求已过期，请刷新页面重试');}}
function setting(string $key,string $default=''): string{$s=db()->prepare('SELECT setting_value FROM settings WHERE setting_key=?');$s->execute([$key]);$v=$s->fetchColumn();return $v===false?$default:(string)$v;}

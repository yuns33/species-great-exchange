<?php
declare(strict_types=1);
if(file_exists(__DIR__.'/../config.php')){die('系统已安装。如需重新安装，请先备份并移除 config.php 和数据库表。');}
$error='';$done=false;
if($_SERVER['REQUEST_METHOD']==='POST'){
 $host=trim($_POST['host']??'localhost');$name=trim($_POST['name']??'species_exchange');$user=trim($_POST['user']??'root');$pass=$_POST['pass']??'';
 $admin=trim($_POST['admin']??'wsz');$password=$_POST['password']??'wsz123456';
 try{
  $pdo=new PDO("mysql:host=$host;charset=utf8mb4",$user,$pass,[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION]);
  $pdo->exec("CREATE DATABASE IF NOT EXISTS `$name` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
  $pdo->exec("USE `$name`");
  $pdo->exec("CREATE TABLE IF NOT EXISTS admins(id INT AUTO_INCREMENT PRIMARY KEY,username VARCHAR(80) NOT NULL UNIQUE,password_hash VARCHAR(255) NOT NULL,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB");
  $pdo->exec("CREATE TABLE IF NOT EXISTS species(id INT AUTO_INCREMENT PRIMARY KEY,slug VARCHAR(100) NOT NULL UNIQUE,name VARCHAR(120) NOT NULL,`group_name` VARCHAR(30) NOT NULL,emoji VARCHAR(20) DEFAULT '',tip TEXT,path_text TEXT,image VARCHAR(500) DEFAULT '',visible TINYINT(1) DEFAULT 1,sort_order INT DEFAULT 0,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB");
  $pdo->exec("CREATE TABLE IF NOT EXISTS settings(setting_key VARCHAR(100) PRIMARY KEY,setting_value TEXT) ENGINE=InnoDB");
  $pdo->prepare("INSERT INTO admins(username,password_hash) VALUES(?,?)")->execute([$admin,password_hash($password,PASSWORD_DEFAULT)]);
  $pdo->exec("INSERT INTO settings(setting_key,setting_value) VALUES('countdown_seconds','0'),('ai_endpoint','https://api.openai.com/v1/chat/completions'),('ai_model','gpt-4o-mini'),('ai_key','') ON DUPLICATE KEY UPDATE setting_key=VALUES(setting_key)");
  $seed=json_decode(file_get_contents(__DIR__.'/../assets/seed_species.json'),true);
  $ins=$pdo->prepare("INSERT INTO species(slug,name,group_name,emoji,tip,path_text,image,visible,sort_order) VALUES(?,?,?,?,?,?,?,?,?)");
  foreach($seed as $i=>$sp){$ins->execute([$sp['id'],$sp['name'],$sp['group'],$sp['emoji'],$sp['tip'],$sp['path'],$sp['image'],1,$i]);}
  $config="<?php\nreturn ".var_export(['db_host'=>$host,'db_name'=>$name,'db_user'=>$user,'db_pass'=>$pass,'db_charset'=>'utf8mb4'],true).";\n";
  file_put_contents(__DIR__.'/../config.php',$config,LOCK_EX);
  $done=true;
 }catch(Throwable $e){$error=$e->getMessage();}
}
?><!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>物种大漂流安装</title><style>
*{box-sizing:border-box}body{margin:0;background:#071d31;color:#f5e8cb;font:15px system-ui;padding:24px}.wrap{max-width:560px;margin:5vh auto;background:#102f47;border:1px solid #b99a61;border-radius:18px;padding:26px;box-shadow:0 20px 60px #0007}h1{color:#f1d69b}label{display:block;margin:14px 0 5px;color:#d8c49c}input{width:100%;padding:12px;border-radius:8px;border:1px solid #60798a;background:#071d31;color:white}button{margin-top:20px;padding:12px 20px;background:#d8b56e;border:0;border-radius:9px;font-weight:bold}.err{color:#ff9b91}.ok{color:#8de0b5}small{color:#adc0c9;line-height:1.7}</style><div class="wrap"><h1>✥ 物种大漂流 · 安装向导</h1><?php if($done):?><h2 class="ok">安装成功！</h2><p>已创建数据库、管理员和 25 条初始物种数据。</p><p><a style="color:#f1d69b" href="../admin/">进入后台</a>　<a style="color:#f1d69b" href="../">打开首页</a></p><p class="err">安全提示：请立即删除 install 目录，或通过服务器面板限制访问。</p><?php else:?><?php if($error):?><p class="err"><?=htmlspecialchars($error)?></p><?php endif;?><form method="post"><label>数据库主机</label><input name="host" value="localhost" required><label>数据库名</label><input name="name" value="species_exchange" required><label>数据库用户名</label><input name="user" value="root" required><label>数据库密码</label><input name="pass" type="password"><hr><label>后台账号</label><input name="admin" value="wsz" required><label>后台密码</label><input name="password" value="wsz123456" required><small>首次安装默认账号 wsz，密码 wsz123456。上线后请在后台修改。</small><br><button>开始安装</button></form><?php endif;?></div></html>
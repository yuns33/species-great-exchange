<?php
require_once __DIR__.'/../includes.php';admin_required();
$in=json_decode(file_get_contents('php://input'),true)?:[];$name=trim($in['name']??'');$group=trim($in['group']??'');$tip=trim($in['tip']??'');
$key=setting('ai_key');$endpoint=setting('ai_endpoint','https://api.openai.com/v1/chat/completions');$model=setting('ai_model','gpt-4o-mini');
if(!$name)json_out(['error'=>'请先填写物种名称'],400);
if(!$key){$text="{$name}原产于{$group}地区。随着远洋航行、新航路开辟以及贸易和人口迁移，{$name}逐步传播到其他地区，并在当地农业、饮食或生态环境中产生影响。注意：这是一段通用示例说明，建议结合可靠资料核对具体传播时间与路线。";json_out(['text'=>$text,'fallback'=>true]);}
$payload=['model'=>$model,'messages'=>[['role'=>'system','content'=>'你是严谨的历史与生物地理科普助手。用中文写一段约80-120字的物种原产地与历史传播路径说明；不确定的细节要明确保留，不要编造。'],['role'=>'user','content'=>"物种：$name；原产大陆：$group；已有介绍：$tip"]],'temperature'=>0.4];
$ch=curl_init($endpoint);curl_setopt_array($ch,[CURLOPT_POST=>true,CURLOPT_RETURNTRANSFER=>true,CURLOPT_HTTPHEADER=>['Content-Type: application/json','Authorization: Bearer '.$key],CURLOPT_POSTFIELDS=>json_encode($payload,JSON_UNESCAPED_UNICODE),CURLOPT_TIMEOUT=>35]);$out=curl_exec($ch);$err=curl_error($ch);$code=curl_getinfo($ch,CURLINFO_HTTP_CODE);curl_close($ch);
if($out===false||$code>=400)json_out(['error'=>'AI 接口调用失败：'.($err?:'HTTP '.$code)],502);$d=json_decode($out,true);$text=$d['choices'][0]['message']['content']??'';if(!$text)json_out(['error'=>'AI 返回内容为空'],502);json_out(['text'=>trim($text)]);

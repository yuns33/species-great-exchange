<?php
require_once __DIR__ . '/../includes.php';

try {
    // 使用 slug 作为前端稳定 ID，避免 id 字段重复别名导致数据错乱。
    $sql = "SELECT
                slug AS id,
                name,
                group_name AS `group`,
                emoji,
                tip,
                path_text AS path,
                image AS img
            FROM species
            WHERE visible = 1
            ORDER BY sort_order ASC, species.id ASC";

    $rows = db()->query($sql)->fetchAll();
    json_out($rows);
} catch (Throwable $e) {
    error_log('[species.php] ' . $e->getMessage());
    json_out(['error' => '物种数据查询失败，请检查服务器 PHP 错误日志'], 500);
}
